package com.drudev.isyarat;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.session.MediaController;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;



public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE = 1234;
    private VideoView videoView;
    private SpeechRecognizer sr;
    EditText textInput;
    String strText;
    private StringBuffer url;
    private List<StringBuffer> mURLs = new LinkedList<StringBuffer>();
    Uri video;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        textInput = (EditText) findViewById(R.id.textInput);
        videoView = (VideoView) findViewById(R.id.viewVid);

        /*video = Uri.parse("http://idnlog.id/isyarat/a/abang_sl.mp4");
        videoView.setVideoURI(video);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
                videoView.start();
            }
        });*/

        final InputMethodManager inputManager = (InputMethodManager) this.getSystemService(getApplicationContext().INPUT_METHOD_SERVICE);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/



                inputManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                textInput.setText("");

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, "com.drudev.isyarat");
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.bicara));
//                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                startActivityForResult(intent, REQUEST_CODE);

            }
        });
    }

    private void textPreprocessing (){


        Toast.makeText(getApplicationContext(), R.string.prosestext, Toast.LENGTH_SHORT).show();


        if(textInput.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), R.string.prosestext, Toast.LENGTH_SHORT).show();
        } else
            strText = textInput.getText().toString();
        /*split input kalimat menjadi kata*/
        String[] words = strText.split("\\s+");

        /*menghapus karakter khusus dan merubah huruf kapital/uppercase menjadi lowercase */
        for (int i = 0; i < words.length; i++) {
            words[i] = words[i].replaceAll("[^\\w]", "");
            words[i] = words[i].toLowerCase();
        }

        for (int i = 0; i < words.length; i++) {
                /*
                * "http://idnblog.id/isyarat/" + FIRST_CHAR + WORD
                * */
            url = new StringBuffer("http://idnlog.id/isyarat/");
            url.append(words[i].charAt(0));
            url.append('/');
            url.append(words[i]);
            url.append(".htm"); //langsng video _sl.mp4 || htm
            mURLs.add(url);
            Log.d("array mURL", mURLs.toString());
        }
        try {
            loadNext();
            Log.d("loadnex","yup");
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ExecutionException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /* Hapus URL satu per satu dari list kemudian ngeload video */
    private void loadNext() throws InterruptedException, ExecutionException {
        if (mURLs.isEmpty()) {
            return;
        }
        url = mURLs.remove(0);
        if (url != null) {
            new LoadVideo().execute();
        }
    }

    private class LoadVideo extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... args) {
            /* if url is URL of number/alphabet */
            if(url.indexOf("angka")>=0 || url.indexOf("huruf")>=0){
                video = Uri.parse(url.toString());
            }

            /* if url is URL of a word */
            else {
                try {
                    Document doc = Jsoup.connect(url.toString()).ignoreContentType(true).get();
                    Element img = doc.select("source[src$=.mp4]").first();
                    String Str = img.attr("abs:src");
                    video = Uri.parse(Str);
//                    video = Uri.parse(url.toString());
                    Log.d("video", video.toString());
                } catch (Exception e) {
                    /*ketika kata tidak ditemukan diubah menjadi huruf*/
                    video = null;
                    String t = url.toString();
                    Log.d("Cek abjad", t);

                    /* Get the word from the URL */
                    String str = t.substring(27, t.lastIndexOf('.'));
                    Log.d("huruf", str);

                    /* Traverse the word from last and add URL for each character to the beginning of URLs list*/
                    for (int i = str.length() - 1; i >= 0; i--) {
                        /* jika karakter adalah angka */
                        if (str.charAt(i) <= '9' && str.charAt(i) >= '0')
                            mURLs.add(0, new StringBuffer("http://idnlog.id/isyarat/angka/bilangan_" + str.charAt(i) + ".mp4"));

                        /* karakter adalah huruf atau abjad */
                        else
                            mURLs.add(0, new StringBuffer("http://idnlog.id/isyarat/0/" + str.charAt(i) + ".mp4"));
                    }
                    Log.d("kata selanjutnya", mURLs.toString());
                    /* Remove the newly added character URL and get the image as bitmap */
                    StringBuffer url = mURLs.remove(0);
                    video = Uri.parse(url.toString());
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            /* The bitmap is set to ImageView onPost downloading and loadNext method is called for next URL in the URLs list*/
            if (video != null) {
                videoView.setVideoURI(video);
                videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
//                        mp.setLooping(true);
                        videoView.start();
                    }
                });

                videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        mp.reset();
                        try {
                            loadNext();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
            /*try {
                loadNext();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ExecutionException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }*/
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            /* matches will contain possible words for voice */
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String topResult;
            /* Choose the first word from the result and append to the edit TextBox */
            topResult = matches.get(0);
            textInput.append(topResult);
            textPreprocessing();

            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
